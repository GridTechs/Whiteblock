# SKALE Network

## Table of Contents

-   [Open Source Plan and Community](OPEN_SOURCE_PLAN.md)
-   [SKALE Developer Community on Discord](http://skale.chat)
-   [Product Updates](/updates)
