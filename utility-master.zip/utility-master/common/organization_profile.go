/**
 * Copyright 2020 Whiteblock Inc. All rights reserved.
 * Use of this source code is governed by a BSD-style
 * license that can be found in the LICENSE file.
 */

package common

type CallToAction struct {
	Icon string `json:"icon,omitempty"`
	Text string `json:"text,omitempty"`
	Link string `json:"link,omitempty"`
}

type OrganizationProfile struct {
	MainCTA   CallToAction   `json:"mainCTA,omitempty"`
	Body      string         `json:"body,omitempty"`
	RightCTAs []CallToAction `json:"rightCTAs,omitempty"`
}
