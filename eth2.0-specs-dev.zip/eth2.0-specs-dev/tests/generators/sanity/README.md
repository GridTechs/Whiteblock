# Sanity tests

Sanity tests cover regular state-transitions in a common block-list format, to ensure the basics work.

Information on the format of the tests can be found in the [sanity test formats documentation](../../specs/test_formats/sanity/README.md).

 

