# Epoch processing

Epoch processing covers the sub-transitions during an epoch change.

An epoch-processing test-runner can consume these sub-transition test-suites,
 and handle different kinds of epoch sub-transitions by processing the cases using the specified test handler.

Information on the format of the tests can be found in the [epoch-processing test formats documentation](../../specs/test_formats/epoch_processing/README.md).

 

