# Genesis test generator

Genesis tests cover the initialization and validity-based launch trigger for the Beacon Chain genesis state.

Information on the format of the tests can be found in the [genesis test formats documentation](../../formats/genesis/README.md).

