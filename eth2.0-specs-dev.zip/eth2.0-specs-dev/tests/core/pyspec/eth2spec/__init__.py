# See setup.py about usage of VERSION.txt
import os
with open(os.path.join(os.path.dirname(__file__), 'VERSION.txt')) as f:
    __version__ = f.read().strip()
